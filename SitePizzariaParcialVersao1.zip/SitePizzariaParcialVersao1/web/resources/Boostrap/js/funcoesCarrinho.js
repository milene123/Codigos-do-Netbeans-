/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function validar(){
      	
	var produto= document.getElementById("txProduto").value;
	var quantidade=document.getElementById("txQtde").value;
	var valor=document.getElementById("txValor").value;	
	
	if (produto==""){
		alert("Campo produto esta vazio..")
	}else 
	if (quantidade==""){
		alert("Campo quantidade esta vazio..")
	}else
	if (valor==""){
		alert("Campo valor esta vazio..")
	}else{
		adicionarProduto();
		listarProdutos();
	}
}
function adicionarProduto(){
	
	produto = "Mussarela";
	quantidade="10";
	valor="10";
	
	if(!localStorage.getItem("carrinho")){	
	
		
		
		object= JSON.stringify({
			produto:document.getElementById("txProduto").value,
			quantidade:document.getElementById("txQtde").value,
			valor:document.getElementById("txValor").value	
		})
		carrinho = [];
		carrinho[0] = object;
		
		localStorage.setItem("carrinho", JSON.stringify(carrinho));	
	}else{			
		
		object= JSON.stringify({
			produto:document.getElementById("txProduto").value,
			quantidade:document.getElementById("txQtde").value,
			valor:document.getElementById("txValor").value
		})

		
		carrinho = JSON.parse(localStorage.getItem("carrinho"));
		qtde = carrinho.length;
		carrinho[qtde] = object;
	
		localStorage.setItem("carrinho",  JSON.stringify(carrinho));
	}
}

function listarProdutos(){
	
	var table = document.getElementById('tbObjetos');
	var row = table.insertRow(1);
	
	var label = document.getElementById('soma');
	
	if(!localStorage.getItem("carrinho")){
			document.getElementById("itensCarrinho").innerHTML  = "Carrinho Vazio!!";
	}else{
		carrinho = JSON.parse(localStorage.getItem("carrinho"));
		
		for(i=0; i < carrinho.length; i++){
			row = table.insertRow(2+i);	
			obj=JSON.parse(carrinho[i]);	
			row.innerHTML ="<tr><td>"+obj.produto+"</td> <td>"+obj.quantidade+"</td>  <td>"+obj.valor+"</td></tr>";
		}

	}
	
}

function esvaziarCarrinho(){
	
		localStorage.removeItem("carrinho");
		listarProdutos();
}

function valores (){
	var qtdeitem=0;
	var valorTotal=0;
	var table = document.getElementById('tbObjetos');
	
	if(!localStorage.getItem("carrinho")){
			document.getElementById("itensCarrinho").innerHTML  = "Carrinho Vazio!!";
	}else{
		carrinho = JSON.parse(localStorage.getItem("carrinho"));
		
		for(i=0; i < carrinho.length; i++){
			obj=JSON.parse(carrinho[i]);
			valorTotal=valorTotal+(obj.valor*obj.quantidade);
			qtdeitem++;
		}
		
		document.getElementById("total").innerHTML  = qtdeitem;
		document.getElementById("valPedidos").innerHTML  = valorTotal;

	}
	
}

