
/*function validar(){
    
    var nome = document.getElementById("txtNome").value;
    var cpf = document.getElementById("txtCpf").value;
    var rua = document.getElementById("txtRua").value;
    var bairro = document.getElementById("txtBairro").value;
    var uf = document.getElementById("txtUf").value;
    var telefone = document.getElementById("txtTelefone").value;
    var email = document.getElementById("txtEmail").value;
    if (nome ==""){
        alert("Informe o nome");
        return false;
    }else if(cpf==""){
        alert("Informe o cpf");
        return false;
    }else if(rua==""){
        alert("Informe a rua");
        return false;
    }
    else if(bairro==""){
        alert("Informe o bairro");
        return false;
    }
    else if(telefone==""){
        alert("Informe o telefone");
        return false;
    }
    else if(email==""){
        alert("Informe o email");
        return false;
    }else{
        return true;
    }
    
    
    }
    
  */ 
             
             $(document).ready(function(){
				
				/*$("#id_nome").css("text-transform", "uppercase");
				$("#id_cpf").css("text-transform", "uppercase");
                                $("#id_rua").css("text-transform", "uppercase");
                                $("#id_bairro").css("text-transform", "uppercase");
                                $("#id_uf").css("text-transform", "uppercase");
                                $("#id_telefone").css("text-transform", "uppercase");
                                $("#id_email").css("text-transform", "uppercase");*/
				$("form").on("submit", function(){
					if($("#id_nome").val() == ''){
						alert('Informe o nome para prosseguir!');
						return false;
					}else if($("#id_cpf").val() == ''){
                                            alert('Informe o cpf para prosseguir!');
                                            return false;
                                        }else if($("#id_rua").val() == ''){
                                            alert('Informe a rua para prosseguir!');
                                            return false;
                                    }else if($("#id_bairro").val() == ''){
                                            alert('Informe o bairro para prosseguir!');
                                            return false;
                                    }else if($("#id_uf").val() == ''){
                                            alert('Informe a uf para prosseguir!');
                                            return false;
                                    }else if($("#id_telefone").val() == ''){
                                            alert('Informe o telefone para prosseguir!');
                                            return false;
                                    }else if($("#id_email").val() == ''){
                                            alert('Informe o email para prosseguir!');
                                            return false;
                                    }else{
						alert("Informação enviada!");
						return true;
					}
				});
                            });
                            
     
            
     