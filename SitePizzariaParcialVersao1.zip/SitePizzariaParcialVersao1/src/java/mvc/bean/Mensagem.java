/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.bean;

public class Mensagem {    
    private int menid;
    private String mennome;
    private String menemail;
    private String mendescricao;
    private String mentipo;

    public String getMentipo() {
        return mentipo;
    }

    public void setMentipo(String mentipo) {
        this.mentipo = mentipo;
    }
    public Mensagem() {}
    

    public Mensagem(int menid, String mennome, String menemail, String mendescricao,String mentipo) {
        this.menid = menid;
        this.mennome = mennome;
        this.menemail = menemail;
        this.mendescricao = mendescricao;
        this.mentipo = mentipo;
    }

    public int getMenid() {
        return menid;
    }

    public void setMenid(int menid) {
        this.menid = menid;
    }

    public String getMennome() {
        return mennome;
    }

    public void setMennome(String mennome) {
        this.mennome = mennome;
    }

    public String getMenemail() {
        return menemail;
    }

    public void setMenemail(String menemail) {
        this.menemail = menemail;
    }

    public String getMendescricao() {
        return mendescricao;
    }

    public void setMendescricao(String mendescricao) {
        this.mendescricao = mendescricao;
    }
    
    
}
