/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.bean;

public class Categoria {    
    private int catid;
    private String catnome;
    
    
    public Categoria() {}
    

    public Categoria(int catid, String catnome) {
        this.catid = catid;
        this.catnome = catnome;
          
    }

    public int getCatid() {
        return catid;
    }

    public void setCatid(int catid) {
        this.catid = catid;
    }

    public String getCatnome() {
        return catnome;
    }

    public void setCatnome(String catnome) {
        this.catnome = catnome;
    }
    
}