/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.bean;

import java.io.Serializable;

public class Administrador  implements Serializable{    
    private int admid;
    private String admnome;
    private String admcpf;
    private String admlogin;
    private String admnsenha;

    public String getAdmnsenha() {
        return admnsenha;
    }

    public void setAdmnsenha(String admnsenha) {
        this.admnsenha = admnsenha;
    }
    

    public String getAdmlogin() {
        return admlogin;
    }

    public void setAdmlogin(String admlogin) {
        this.admlogin = admlogin;
    }

    public String getAdmsenha() {
        return admsenha;
    }

    public void setAdmsenha(String admsenha) {
        this.admsenha = admsenha;
    }
    private String admsenha;
    public Administrador() {}
    

    public Administrador(int admid, String admnome, String admcpf,String admlogin,String admsenha) {
        this.admid = admid;
        this.admnome = admnome;
        this.admcpf= admcpf;
       this.admlogin= admlogin;
        this.admsenha= admsenha;
        
    }
    public int getAdmid() {
        return admid;
    }

    public void setAdmid(int admid) {
        this.admid = admid;
    }

    public String getAdmnome() {
        return admnome;
    }

    public void setAdmnome(String admnome) {
        this.admnome = admnome;
    }

    public String getAdmcpf() {
        return admcpf;
    }

    public void setAdmcpf(String admcpf) {
        this.admcpf = admcpf;
    }
 
}
    

