/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.bean;

/**
 *
 * @author Lucas Souza
 */
public class Curriculo {
    private long curid;
    private String curnome;
    private String curemail;
    private String curtelefone;
    private String curformacao;
    private String caminho;
    
    
    public Curriculo() {
    }
    
    public long getCurid() {
        return curid;
    }

    public void setCurid(long curid) {
        this.curid = curid;
    }

    public String getCurnome() {
        return curnome;
    }

    public void setCurnome(String curnome) {
        this.curnome = curnome;
    }

    public String getCuremail() {
        return curemail;
    }

    public void setCuremail(String curemail) {
        this.curemail = curemail;
    }

    public String getCurtelefone() {
        return curtelefone;
    }

    public void setCurtelefone(String curtelefone) {
        this.curtelefone = curtelefone;
    }

    public String getCurformacao() {
        return curformacao;
    }

    public void setCurformacao(String curformacao) {
        this.curformacao = curformacao;
    }

    public String getCaminho() {
        return caminho;
    }

    public void setCaminho(String caminho) {
        this.caminho = caminho;
    }

}
