/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;
import mvc.bean.Curriculo;
import mvc.dao.CurriculoDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;


@Controller
public class CurriculoController {
    private final CurriculoDAO dao;
    
    @Autowired
    public CurriculoController(CurriculoDAO dao) {
        this.dao = dao;
    }
    
    @RequestMapping("/formAdicionaCurriculo")
    public String form(){
        return "curriculo/formAdicionaCurriculo";
    }
    
    @RequestMapping(value = "/adicionaCurriculo", method = RequestMethod.POST)
    public String adiciona(HttpServletRequest request, Model model){
        try {
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile multipartFile = multipartRequest.getFile("caminho");
           
            String destinyPath = " C:\\Users\\x450l\\Documents\\NetBeansProjects\\Versao4SitePizzaria\\SitePizzariaParcialVersao1\\SitePizzariaParcialVersao1\\web\\resources\\curriculos";
            if(!(new File(destinyPath)).exists()){
                (new File(destinyPath)).mkdir();
            }
            
            String photoName = multipartFile.getOriginalFilename();
            String photoPath = destinyPath + photoName;
                       
            File photoFile = new File(photoPath);
            multipartFile.transferTo(photoFile);
            
            String caminho = "/resources/uploads/curriculos/"+photoName;
            
            Curriculo curriculo =new Curriculo();
            curriculo.setCurnome(request.getParameter("curnome"));
            curriculo.setCuremail(request.getParameter("curemail"));
            curriculo.setCurtelefone(request.getParameter("curtelefone"));
            curriculo.setCurformacao(request.getParameter("curfomacao"));
            curriculo.setCaminho(caminho);           
            
            dao.adicionaCurriculo(curriculo);            
            return "curriculo/curriculo-adicionado";
            
        } catch (IOException ex) {
            model.addAttribute("erro", ex.toString());
            return "curriculo/curriculo-erro-adicao";
        } 
    }
    
    @RequestMapping("/listaCurriculos")
    public String lista(Model model){
        model.addAttribute("listaCurriculos", dao.listarCurriculos());
        return "curriculo/listagem-curriculo";
    }
    
    /*
    @RequestMapping("/listaCurriculos")
    public String lista(Model model) throws IOException{
        List<Curriculo> listaCurriculos = dao.listarCurriculos();
        
        setImagePath(listaCurriculos);
        
        for (Curriculo listaCurriculo : listaCurriculos) {
            System.out.println(""+ listaCurriculo.getCaminho());
        }
        
        model.addAttribute("listaCurriculos", dao.listarCurriculos());
        return "curriculo/listagem-curriculos";
    }
    private void setImagePath(List<Curriculo> listaCurriculos) throws IOException{
        
        for (Curriculo curriculo : listaCurriculos) {
            
            BufferedImage bImage = ImageIO.read(new File(curriculo.getCaminho()));
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write( bImage, "jpg", baos );
            baos.flush();
            byte[] imageInByteArray = baos.toByteArray();
            baos.close();                                   
            String b64 = DatatypeConverter.printBase64Binary(imageInByteArray);
            curriculo.setCaminho(b64);
            
        }
            
    }*/
    
    
    @RequestMapping("/exibeCurriculo")
    public String exibe(Long id, Model model){
        model.addAttribute("curriculo", dao.buscarCurriculoPorId(id));
        return "curriculo/exibe-curriculo";
    }
}
