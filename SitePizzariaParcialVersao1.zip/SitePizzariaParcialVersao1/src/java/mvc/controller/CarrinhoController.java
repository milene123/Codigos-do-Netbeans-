/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controller;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import mvc.bean.ItemsCarrinho;
import mvc.bean.Produto;
import mvc.dao.ProdutoDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CarrinhoController {

    private final ProdutoDao dao;
    private float total=0;

    private List<ItemsCarrinho> carrinho = new ArrayList<>();

    @Autowired
    public CarrinhoController(ProdutoDao dao) {
        this.dao = dao;
    }
    
    /**
     * Metodo responsavel por mostra a lista di carrinho
     * @param model
     * @return 
     */
    @RequestMapping("/mostrarCarrinho")
    public String showCarrinho(Model model) {
        totalPedido();
        model.addAttribute("ptotal", this.total);
        model.addAttribute("p", carrinho);

        return "produto/listagem-carrinho";
    }

    /**
     * Metodo que mostra o detalhe do produto selecionado
     * @param id
     * @param model
     * @return 
     */
   
    @RequestMapping("/formCarrinho")
    public String produtoDetale(Long id, Model model) {
        Produto produto = dao.buscarProdutoPorId(id);
        model.addAttribute("p", produto);
        
      
        return "produto/detalhe-produto";
    }

    /**
     * Metodo que inseri a produto no carrinho
     * @param id
     * @param model
     * @param request
     * @return 
     */
    @RequestMapping("/formCadCompra")
    public String produtoCarrinho(Long id, Model model, HttpServletRequest request) {

        Produto buscaProduto = dao.buscarProdutoPorId(id);
        ItemsCarrinho itens = new ItemsCarrinho();
        itens.setId(Long.valueOf(buscaProduto.getProid()));
        itens.setDescrição(buscaProduto.getProdescricao());
        itens.setValor(buscaProduto.getProvalor());
        itens.setQtde(Integer.parseInt(request.getParameter("quantidade")));
       
        carrinho.add(itens);

        model.addAttribute("p", carrinho);
        totalPedido();
        model.addAttribute("ptotal", this.total);

        return "produto/listagem-carrinho";
    }
    
    /**
     * Metodo que Exclui item do carrinho
     * @param id
     * @param model
     * @return 
     */

    @RequestMapping("/removeProdListaCarrinho")
    public String removeItemCarrinho(Long id, Model model) {
        float total=0;
        
        for (int i = 0; i < carrinho.size(); i++) {
            if (carrinho.get(i).getId()==id){
                carrinho.remove(carrinho.get(i));
            }
        }
        
        model.addAttribute("p", carrinho);

        return "redirect:/mostrarCarrinho";
    }
    /**
     * Metodo pra retornar o totalpedido
     */
    public void totalPedido(){
        this.total=0;
        for (ItemsCarrinho itemsCarrinho : carrinho) {
            this.total= this.total+itemsCarrinho.getSubtotal();
        }
       
    }

    
}
