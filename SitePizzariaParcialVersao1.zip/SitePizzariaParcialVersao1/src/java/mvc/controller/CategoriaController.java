/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controller;

import mvc.bean.Categoria;
import mvc.dao.CategoriaDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author e100349
 */
@Controller
public class CategoriaController {
      private final CategoriaDAO dao;
    
    @Autowired
    public CategoriaController(CategoriaDAO dao) {
        this.dao = dao;
    }
    

    @RequestMapping("/formCategoria")
    public String form(){
        return "categoria/formAdicionaCategoria";
    }
    
    @RequestMapping("/adicionaCategoria")
    public String adiciona(Categoria categoria){

       //System.out.println("oi2222"+ categoria.getCatnome());
        /*if(result.hasErrors()){
            System.out.println(result.hasErrors());
            return "categoria/formularioAdicionaCategoria";
        }*/

        dao.adicionaCategoria(categoria);
        //return "categoria/formularioAdicionaCategoria";
        return "categoria/categoria-adicionada";
    }
    @RequestMapping("/formListarCategorias")
    public String formListar(){
        return "categoria/listagem-categoria";
    }
    
   @RequestMapping("/listCategorias")
    public String lista(Model model){
        model.addAttribute("listCategoria", dao.listarCategorias());
        //System.out.println(dao.listarCategorias());
        return "categoria/listagem-categoria";
    }
    
    @RequestMapping("/removeCategoria")
    public String remove(Integer catid){
        dao.removerCategoria(catid);
        return "categoria/categoria-excluida";
    }
    
    @RequestMapping("/exibeCategoria")
    public String exibe(Integer catid, Model model){
        model.addAttribute("categoria", dao.buscarCategoriaPorId(catid));
        return "categoria/exibe-categoria";
    }
    
    @RequestMapping("/alteraCategoria")
    public String altera(Categoria categoria){
       /*if(result.hasErrors()){
            return "categoria/exibe-categoria";
       }*/
       dao.alteraCategoria(categoria);
       return "redirect:/listCategorias";
    }
    
}
