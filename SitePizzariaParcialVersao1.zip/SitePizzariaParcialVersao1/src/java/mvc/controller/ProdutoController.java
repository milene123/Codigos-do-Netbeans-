package mvc.controller;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.xml.bind.DatatypeConverter;
import mvc.bean.Produto;
import mvc.dao.CategoriaDAO;
import mvc.dao.ProdutoDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@Controller
public class ProdutoController {
    
    private final ProdutoDao dao;
    //private final AdministradorDao dao1;
    private final CategoriaDAO dao1;
    @Autowired
    public ProdutoController(ProdutoDao dao, CategoriaDAO dao1) {
        this.dao = dao;
        this.dao1=dao1;
    }
    
    // Chama a tela de cadastro
    @RequestMapping("/formCadProduto")
    public String form(Model model){
        model.addAttribute("cats", dao1.listarCategorias());
        return "produto/formCadastroProduto";
    }
    /*@RequestMapping("/adicionarProduto")
    public String adiciona(Produto produto){
    dao.adicionarProduto(produto);
        return "produto/produto-adicionado";
    }*/
     @RequestMapping(value="/adicionarProduto", method=RequestMethod.POST)
    public String adiciona(HttpServletRequest request, Model model){
        /*
        Configuracoes necessárias
        Fonte: http://www.pablocantero.com/blog/2010/09/29/upload-com-spring-mvc/
        */
        try {
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile multipartFile = multipartRequest.getFile("proimagem");
            
            String destinyPath = "C:\\imagem_pizzas\\";
            if(!(new File(destinyPath)).exists()){
                (new File(destinyPath)).mkdir();
            }
            
            String photoName = multipartFile.getOriginalFilename();
            String photoPath = destinyPath + photoName;
                       
            File photoFile = new File(photoPath);
            multipartFile.transferTo(photoFile);
            
            //backup
            //File destinationDir = new File(applicationPath);
            //FileUtils.copyFileToDirectory(photoFile, destinationDir);
            
            Produto produto = new Produto();
            produto.setProdescricao(request.getParameter("prodescricao"));
           
            produto.setProquantde(Integer.valueOf(request.getParameter("proquantde")));
            //produto.setProquantde(request.getParameter("proquantde"));
            produto.setProvalor(Float.MAX_VALUE);
            produto.setProimagem(photoPath);           
           // produto.setProid(Integer.valueOf(request.getParameter("proid")));
            produto.setProcatid(Integer.valueOf(request.getParameter("procatid")));
            dao.adicionarProduto(produto);            
            return "redirect:/listaProduto";
            
        } catch (IOException ex) {
            model.addAttribute("erro", ex.toString());
            return "produto/usuario-erro-adicao";
        } 
       // return null;
    }
    

     private void setImagePath(List<Produto> listarProdutos) throws IOException{
         
        for (Produto produto : listarProdutos) {
         System.out.println("teste====================="+produto.getProimagem());   
            BufferedImage bImage = ImageIO.read(new File(produto.getProimagem()));
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write( bImage, "jpg", baos );
            baos.flush();
            byte[] imageInByteArray = baos.toByteArray();
            baos.close();                                   
            String b64 = DatatypeConverter.printBase64Binary(imageInByteArray);
            produto.setProimagem(b64);
            
        }
            
    }
      @RequestMapping("/listaProduto")
    public String lista(Model model) throws IOException{
        List<Produto> listaProdutos = dao.listarProdutos();
        
        setImagePath(listaProdutos);
        
        for (Produto listaProduto : listaProdutos) {
            System.out.println("------------------------"+ listaProduto.getProimagem());
        }
        
        model.addAttribute("listarProdutos", listaProdutos);
        return "produto/formListaProduto";
    }
    /*
    @RequestMapping("/listaProduto")
    public String lista(Model model){
        model.addAttribute("listarProdutos", dao.listarProdutos());
        return "produto/formListaProduto";
    }*/
   /* @RequestMapping("/listaProImagem")
    public String listaImagem (Model model) {
        model.addAttribute("listaPro", dao.listarProdutos());
        return "produto/listaProdutos";
    }
    */
    @RequestMapping("/removerProduto")
    public String remove(Long id){
        dao.removerTarefa(id);
        return "redirect:/listaProduto";
    }
    
    // Exibir dados para auterar
    
    @RequestMapping("/exibeProduto")
    public String exibe(Long id, Model model){
        model.addAttribute("pro", dao.buscarProdutoPorId(id));
        return "produto/formAlterarProduto";
    }
    
    @RequestMapping("/alteraProduto")
    public String altera(Produto produto){
       
        dao.alterar(produto);
       return "redirect:/listaProduto";
    }
    
    
    
    
}
