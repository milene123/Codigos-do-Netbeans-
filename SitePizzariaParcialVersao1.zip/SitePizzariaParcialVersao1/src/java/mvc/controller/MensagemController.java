/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controller;

import java.util.List;
import mvc.bean.Mensagem;
import mvc.dao.MensagemDAO;
import mvc.dao.TipoMensagem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author e100349
 */
@Controller
public class MensagemController {
      private final MensagemDAO dao;
    
    @Autowired
    public MensagemController(MensagemDAO dao) {
        this.dao = dao;
    }
  

    @RequestMapping("/formMensagem")
    public String form(){
        
        //model.addAttribute("tipoMensagem", TipoMensagem.values());
        
        return "mensagem/formAdicionaMensagem";
    }
    
    @RequestMapping("/adicionaMensagem")
    public String adiciona(Mensagem mensagem){

       //System.out.println("oi2222"+ categoria.getCatnome());
        /*if(result.hasErrors()){
            System.out.println(result.hasErrors());
            return "categoria/formularioAdicionaCategoria";
        }*/

        dao.adicionaMensagem(mensagem);
        //return "categoria/formularioAdicionaCategoria";
        return "mensagem/mensagem-adicionada";
    }
    @RequestMapping("/formListarMensagens")
    public String formListar(){
        return "mensagem/listagem-mensagem";
    }
    
   @RequestMapping("/listMensagens")
    public String lista(Model model){
        model.addAttribute("listarMensagens", dao.listarMensagens());
        //System.out.println(dao.listarCategorias());
        return "mensagem/listagem-mensagem";
    }
    
    @RequestMapping("/removeMensagem")
    public String remove(Integer menid){
        dao.removerMensagem(menid);
        return "mensagem/mensagem-removida";
    }
    
    @RequestMapping("/exibeMensagens")
    public String exibe(Integer menid, Model model){
        model.addAttribute("mensagem", dao.buscarMensagemPorId(menid));
        return "mensagem/exibe-mensagem";
    }
    
    @RequestMapping("/alteraMensagem")
    public String altera(Mensagem mensagem){
       /*if(result.hasErrors()){
            return "categoria/exibe-categoria";
       }*/
       dao.alteraMensagem(mensagem);
       return "mensagem/mensagem-alterada";
    }
    
}
