/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import mvc.bean.Administrador;
import mvc.dao.AdministradorDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author e100349
 */
@Controller
public class AdministradorController {
    private final AdministradorDAO dao;
    
    @Autowired
    public AdministradorController(AdministradorDAO dao) {
        this.dao = dao;
    }
    
   
     @RequestMapping("/formLogin")
    public String formLogin(){
        return "administrador/login-adm";
    }
    
    @RequestMapping("/efetuaLogin")
    public String efetuaLogin(Administrador user, HttpSession session){
      
        if(dao.validaAdm(user)){
            session.setAttribute("usuarioLogado", user);
            session.removeAttribute("msgLoginInvalido");
            return "administrador/menu-adm";
        }else{
            session.setAttribute("msgLoginInvalido", "O login não foi validado!");
            return "redirect:formLogin";
        }
        
    }
     @RequestMapping("logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
   
    
    @RequestMapping("/formAdicionaAdm")
    public String form(){
        return "administrador/formAdicionaAdministrador";
    }
    
    @RequestMapping("adicionaAdministrador")
    public String adiciona(Administrador administrador){
        dao.adicionaAdministrador(administrador);
        return "administrador/administrador-adicionado";
    }
    
    @RequestMapping("/listaAdms")
    public String lista(Model model){
        model.addAttribute("listaAdms", dao.listarAdministradores());
        return "administrador/listagem-administrador";
    }
     @RequestMapping("/menuAdm")
    public String menu(){
        return "administrador/menu-adm";
    }
   
     @RequestMapping("/removeAdm")
    public String remove(Integer id){
        dao.removerAdministrador(id);
        return "redirect:/listagem-administrador";
    }
    
    @RequestMapping("/exibeAdm")
    public String exibe(Integer id, Model model){
        model.addAttribute("adm", dao.buscarAdministradorPorId(id));
        return "administrador/exibe-administrador";
    }
    
    @RequestMapping("/alteraAdm")
    public String altera(@Valid Administrador administrador, BindingResult result){
       if(result.hasErrors()){
            return "administrador/exibe-administrador";
       }
       dao.alteraAdministrador(administrador);
       return "redirect:/listaAdms";
    }
}