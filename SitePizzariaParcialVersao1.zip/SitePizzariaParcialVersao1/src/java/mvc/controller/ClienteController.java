/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controller;

import javax.servlet.http.HttpSession;
import mvc.bean.Cliente;
import mvc.dao.ClienteDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author e100349
 */
@Controller
public class ClienteController {
      private final ClienteDAO dao;
    
    @Autowired
    public ClienteController(ClienteDAO dao) {
        this.dao = dao;
    }
    @RequestMapping("/")
    public String index(){
        return "index";
    }

    @RequestMapping("/formCliente")
    public String form(){
        return "cliente/formAdicionaCliente";
    }
    
    @RequestMapping("/adicionaCliente")
    public String adiciona(Cliente cliente){

       //System.out.println("oi2222"+ categoria.getCatnome());
        /*if(result.hasErrors()){
            System.out.println(result.hasErrors());
            return "categoria/formularioAdicionaCategoria";
        }*/

        dao.adicionaCliente(cliente);
        //return "categoria/formularioAdicionaCategoria";
        return "cliente/cliente-adicionado";
    }
    @RequestMapping("/formListarClientes")
    public String formListar(){
        return "cliente/listagem-cliente";
    }
    
   @RequestMapping("/listClientes")
    public String lista(Model model){
        model.addAttribute("listCliente", dao.listarClientes());
        //System.out.println(dao.listarCategorias());
        return "cliente/listagem-cliente";
    }
    
    @RequestMapping("/removeCliente")
    public String remove(Integer cliid){
        dao.removerCliente(cliid);
        return "cliente/cliente-excluido";
    }
    /*@RequestMapping("/menRemoveCliente")
    public String menRemoverCliente(Integer cliid){
        return "cliente/cliente-excluido";
    }*/
    
    @RequestMapping("/exibeCliente")
    public String exibe(Integer cliid, Model model){
        model.addAttribute("cliente", dao.buscarClientePorId(cliid));
        return "cliente/exibe-cliente";
    }
    
    @RequestMapping("/alteraCliente")
    public String altera(Cliente cliente){
       /*if(result.hasErrors()){
            return "categoria/exibe-categoria";
       }*/
       dao.alteraCliente(cliente);
       //return "redirect:/listClientes";
       return "cliente/cliente-alterado";
    }
    @RequestMapping("/formLoginCliente")
    public String formLogin(){
        return "cliente/cliente-login";
    }
    @RequestMapping("/efetuaLoginCliente")
    public String efetuaLogin(Cliente user, HttpSession session){
        if(dao.validaCliente(user)){
            session.setAttribute("usuarioLogado", user);
            session.removeAttribute("msgLoginInvalido");
            return "cliente/menu-cliente";
        }else{
            session.setAttribute("msgLoginInvalido", "O login não foi validado!");
            return "redirect:formLoginCliente";
        }
        
    }
    
    
}
