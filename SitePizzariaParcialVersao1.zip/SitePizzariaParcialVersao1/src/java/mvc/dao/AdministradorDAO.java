/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import mvc.bean.Administrador;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AdministradorDAO {
    
    private final Connection connection;
    
    @Autowired
    public AdministradorDAO(DataSource dataSource){
        try {
            this.connection = dataSource.getConnection();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
       public boolean validaAdm(Administrador user){
       String sql = " select admlogin, admsenha from administrador where admlogin =? and admsenha=?";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
           
        stmt.setString(1,user.getAdmlogin());
        stmt.setString(2,user.getAdmsenha());
        
     stmt.execute();
        
        if(stmt.execute()) {
          return true;        
        }else{
            return false;
        }
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
    }
    
    
    
    
    public boolean adicionaAdministrador(Administrador administrador){
       String sql = "insert into administrador (admnome, admcpf,admlogin,admsenha) values (?,?,?,?)";
       try ( 
        // prepared statement para inserção
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        // seta os valores
        stmt.setString(1,administrador.getAdmnome());
        stmt.setString(2,administrador.getAdmcpf());
        stmt.setString(3,administrador.getAdmlogin());
        stmt.setString(4,administrador.getAdmsenha());
        // executa
        stmt.execute();
       } catch (SQLException e) {
         e.printStackTrace();
       }
       return true;
    }    
    
    public List<Administrador> listarAdministradores(){
       List<Administrador> listarAdministradores = new ArrayList<Administrador>();
       String sql = "select * from administrador order by admnome";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
           Administrador administrador = new Administrador();
           administrador.setAdmid(rs.getInt("admid"));
           administrador.setAdmnome(rs.getString("admnome"));
           administrador.setAdmcpf(rs.getString("admcpf"));
           administrador.setAdmlogin(rs.getString("admlogin"));
           administrador.setAdmsenha(rs.getString("admsenha"));
   /*        categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               categoria.setDataFinalizacao(data);
           }*/        
           listarAdministradores.add(administrador);           
        }
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return listarAdministradores;
    }
    
    public Administrador buscarAdministradorPorId(Integer admid){
       String sql = "select * from administrador where admid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,admid);
        ResultSet rs = stmt.executeQuery();
        Administrador administrador = new Administrador();
        if(rs.next()) {
           administrador.setAdmid(rs.getInt("admid"));
           administrador.setAdmnome(rs.getString("admnome"));
           administrador.setAdmcpf(rs.getString("admcpf"));
           administrador.setAdmlogin(rs.getString("admlogin"));
           administrador.setAdmsenha(rs.getString("admsenha"));
           
        /*   categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               System.out.println("data");
               categoria.setDataFinalizacao(data);
           }  */              
        }
        return administrador;
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
    }
    
    public boolean removerAdministrador(Integer admid){
       String sql = "delete from administrador where admid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,admid);
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
    
    
    public boolean alteraAdministrador(Administrador administrador){
       String sql = "update administrador set admnome = ?, admcpf = ? ,admlogin = ?,admsenha = ? where admid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1,administrador.getAdmnome());
        stmt.setString(2,administrador.getAdmcpf());
        stmt.setString(3,administrador.getAdmlogin());
        stmt.setString(4,administrador.getAdmsenha());
   
   /*     stmt.setBoolean(4,categoria.isFinalizado());
        if(categoria.getDataFinalizacao() != null){
            stmt.setDate(3, new Date(categoria.getDataFinalizacao().getTimeInMillis()));
        }else{
            stmt.setNull(3, java.sql.Types.DATE);
        }*/
        stmt.setInt(5,administrador.getAdmid());
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
     
    
}