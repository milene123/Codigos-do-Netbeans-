/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import mvc.bean.Curriculo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class CurriculoDAO {
    private final Connection connection;
    
    @Autowired
    public CurriculoDAO(DataSource dataSource){
        try {
            this.connection = dataSource.getConnection();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
     public boolean adicionaCurriculo(Curriculo curriculo){
       String sql = "insert into curriculo (curnome,curemail,curtelefone,curformacao,caminho,curcpf) values (?,?,?,?,?,?)";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1,curriculo.getCurnome());
        stmt.setString(2,curriculo.getCuremail());
        stmt.setString(3,curriculo.getCurtelefone());
        stmt.setString(4,curriculo.getCurformacao());
        stmt.setString(5,curriculo.getCaminho());
        stmt.setString(6,curriculo.getCurcpf());
        
        stmt.execute();
        
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
    
    public List<Curriculo> listarCurriculos(){
       List<Curriculo> listaCurriculos = new ArrayList<Curriculo>();
       String sql = "select * from curriculo order by curid";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
           Curriculo curriculo = new Curriculo();
           curriculo.setCurid(rs.getLong("curid"));
           curriculo.setCurnome(rs.getString("curnome"));
           curriculo.setCuremail(rs.getString("curemail"));
           curriculo.setCurtelefone(rs.getString("curtelefone"));
           curriculo.setCurformacao(rs.getString("curformacao"));
           curriculo.setCaminho(rs.getString("caminho"));
           listaCurriculos.add(curriculo);               
        }
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return listaCurriculos;
    }
    
    
    public Curriculo buscarCurriculoPorId(Long id){
        String sql = "select * from curriculo where curid = ?";
        try(PreparedStatement stmt = connection.prepareStatement(sql)){
            stmt.setLong(1, id);
            ResultSet rs = stmt.executeQuery();
            Curriculo curriculo = new Curriculo();
            if(rs.next()){
                curriculo.setCurid(rs.getLong("curid"));
                curriculo.setCaminho(rs.getString("caminho"));             
            }
            return curriculo;
        }catch(SQLException e){
            System.out.println("Erro em CurriculoDAO - Buscar por ID: "+e.getMessage());
        }
        return null;
    }
}
