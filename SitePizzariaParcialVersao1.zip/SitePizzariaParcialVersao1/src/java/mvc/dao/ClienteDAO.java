/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import mvc.bean.Cliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ClienteDAO {
    
    private final Connection connection;
    
    @Autowired
    public ClienteDAO(DataSource dataSource){
        try {
            this.connection = dataSource.getConnection();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public boolean adicionaCliente(Cliente cliente){
       String sql = "insert into cliente (clinome, clicpf, clifone, clibairro, clilogradouro, clinumcasa,clilogin,clisenha) values (?,?,?,?,?,?,?,?)";
       try ( 
        // prepared statement para inserção
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        // seta os valores
        stmt.setString(1,cliente.getClinome());
        stmt.setString(2,cliente.getClicpf());
        stmt.setString(3,cliente.getClifone());
        stmt.setString(4,cliente.getClibairro());
        stmt.setString(5,cliente.getClilogradouro());
        stmt.setString(6,cliente.getClinumcasa());
        stmt.setString(7,cliente.getClilogin());
        stmt.setString(8,cliente.getClisenha());
        
        
        // executa
        stmt.execute();
       } catch (SQLException e) {
         e.printStackTrace();
       }
       return true;
    }    
    
    public List<Cliente> listarClientes(){
       List<Cliente> listarClientes = new ArrayList<Cliente>();
       String sql = "select * from cliente order by clinome";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
           Cliente cliente = new Cliente();
           cliente.setCliid(rs.getInt("cliid"));
           cliente.setClinome(rs.getString("clinome"));
           cliente.setClicpf(rs.getString("clicpf"));
           cliente.setClifone(rs.getString("clifone"));
           cliente.setClibairro(rs.getString("clibairro"));
           cliente.setClilogradouro(rs.getString("clilogradouro"));
           cliente.setClinumcasa(rs.getString("clinumcasa"));
           cliente.setClilogin(rs.getString("clilogin"));
           cliente.setClisenha(rs.getString("clisenha"));
   /*        categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               categoria.setDataFinalizacao(data);
           }*/        
           listarClientes.add(cliente);           
        }
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return listarClientes;
    }
    
    public Cliente buscarClientePorId(Integer cliid){
       String sql = "select * from cliente where cliid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,cliid);
        ResultSet rs = stmt.executeQuery();
        Cliente cliente = new Cliente();
        if(rs.next()) {
           cliente.setCliid(rs.getInt("cliid"));
           cliente.setClinome(rs.getString("clinome"));
           cliente.setClicpf(rs.getString("clicpf"));
           cliente.setClifone(rs.getString("clifone"));
           cliente.setClibairro(rs.getString("clibairro"));
           cliente.setClilogradouro(rs.getString("clilogradouro"));
           cliente.setClinumcasa(rs.getString("clinumcasa"));
           cliente.setClilogin(rs.getString("clilogin"));
           cliente.setClisenha(rs.getString("clisenha"));
           
        /*   categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               System.out.println("data");
               categoria.setDataFinalizacao(data);
           }  */              
        }
        return cliente;
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
    }
    
    public boolean removerCliente(Integer cliid){
       String sql = "delete from cliente where cliid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,cliid);
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
    
    public boolean alteraCliente(Cliente cliente){
       String sql = "update cliente set clinome = ?, clicpf = ?, clifone = ?, clibairro = ?,"
                  + " clilogradouro=?, clinumcasa=?,clilogin=?,clisenha=? where cliid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1,cliente.getClinome());
        stmt.setString(2,cliente.getClicpf());
        stmt.setString(3,cliente.getClifone());
        stmt.setString(4,cliente.getClibairro());
        stmt.setString(5,cliente.getClilogradouro());
        stmt.setString(6,cliente.getClinumcasa());
        stmt.setString(7,cliente.getClilogin());
        stmt.setString(8,cliente.getClisenha());
   /*     stmt.setBoolean(4,categoria.isFinalizado());
        if(categoria.getDataFinalizacao() != null){
            stmt.setDate(3, new Date(categoria.getDataFinalizacao().getTimeInMillis()));
        }else{
            stmt.setNull(3, java.sql.Types.DATE);
        }*/
        stmt.setInt(9,cliente.getCliid());
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
    public boolean validaCliente(Cliente user){
       String sql = "select * from cliente where clilogin = ? and clisenha = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1,user.getClilogin());
        stmt.setString(2,user.getClisenha());
        //ResultSet rs = stmt.executeQuery();
       stmt.execute();
        
        if(stmt.execute()) {
          return true;        
        }else{
            return false;
        }
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
    }
}
