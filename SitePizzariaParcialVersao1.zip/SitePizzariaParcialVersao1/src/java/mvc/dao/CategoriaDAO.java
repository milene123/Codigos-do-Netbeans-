/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import mvc.bean.Categoria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CategoriaDAO {
    
    private final Connection connection;
    
    @Autowired
    public CategoriaDAO(DataSource dataSource){
        try {
            this.connection = dataSource.getConnection();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public boolean adicionaCategoria(Categoria categoria){
       String sql = "insert into categoria (catnome) values (?)";
       try ( 
        // prepared statement para inserção
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        // seta os valores
        stmt.setString(1,categoria.getCatnome());
        
        // executa
        stmt.execute();
       } catch (SQLException e) {
         e.printStackTrace();
       }
       return true;
    }    
    
    public List<Categoria> listarCategorias(){
       List<Categoria> listarCategorias = new ArrayList<Categoria>();
       String sql = "select * from categoria order by catnome";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
           Categoria categoria = new Categoria();
           categoria.setCatid(rs.getInt("catid"));
           categoria.setCatnome(rs.getString("catnome"));
       
   /*        categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               categoria.setDataFinalizacao(data);
           }*/        
           listarCategorias.add(categoria);   
           
        }
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       
         return listarCategorias;
      
    }
    
    public Categoria buscarCategoriaPorId(Integer catid){
       String sql = "select * from categoria where catid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,catid);
        ResultSet rs = stmt.executeQuery();
        Categoria categoria = new Categoria();
        if(rs.next()) {
           categoria.setCatid(rs.getInt("catid"));
           categoria.setCatnome(rs.getString("catnome"));
           
        /*   categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               System.out.println("data");
               categoria.setDataFinalizacao(data);
           }  */              
        }
        return categoria;
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
    }
    
    public boolean removerCategoria(Integer catid){
       String sql = "delete from categoria where catid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,catid);
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
    
    public boolean alteraCategoria(Categoria categoria){
       String sql = "update categoria set catnome = ? where catid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1,categoria.getCatnome());
   
   /*     stmt.setBoolean(4,categoria.isFinalizado());
        if(categoria.getDataFinalizacao() != null){
            stmt.setDate(3, new Date(categoria.getDataFinalizacao().getTimeInMillis()));
        }else{
            stmt.setNull(3, java.sql.Types.DATE);
        }*/
        stmt.setInt(2,categoria.getCatid());
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
}
