/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import mvc.bean.Mensagem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MensagemDAO {
    
    private final Connection connection;
    
    @Autowired
    public MensagemDAO(DataSource dataSource){
        try {
            this.connection = dataSource.getConnection();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public boolean adicionaMensagem(Mensagem mensagem){
       String sql = "insert into mensagem (mennome, menemail, mendescricao,mentipo) values (?,?,?,?)";
       try ( 
        // prepared statement para inserção
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        // seta os valores
        stmt.setString(1,mensagem.getMennome());
        stmt.setString(2,mensagem.getMenemail());
        stmt.setString(3,mensagem.getMendescricao());
        stmt.setString(4,mensagem.getMentipo());
        
        // executa
        stmt.execute();
       } catch (SQLException e) {
         e.printStackTrace();
       }
       return true;
    }    
    
    public List<Mensagem> listarMensagens(){
       List<Mensagem> listarMensagens = new ArrayList<Mensagem>();
       String sql = "select * from mensagem order by mennome";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
           Mensagem mensagem = new Mensagem();
           mensagem.setMenid(rs.getInt("menid"));
           mensagem.setMennome(rs.getString("mennome"));
           mensagem.setMenemail(rs.getString("menemail"));
           mensagem.setMendescricao(rs.getString("mendescricao"));
           mensagem.setMentipo(rs.getString("mentipo"));
          
   /*        categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               categoria.setDataFinalizacao(data);
           }*/        
           listarMensagens.add(mensagem);           
        }
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return listarMensagens;
    }
    
    public Mensagem buscarMensagemPorId(Integer menid){
       String sql = "select * from mensagem where menid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,menid);
        ResultSet rs = stmt.executeQuery();
        Mensagem mensagem = new Mensagem();
        if(rs.next()) {
           mensagem.setMenid(rs.getInt("menid"));
           mensagem.setMennome(rs.getString("mennome"));
           mensagem.setMenemail(rs.getString("menemail"));
           mensagem.setMendescricao(rs.getString("mendescricao"));
           mensagem.setMentipo(rs.getString("mentipo"));
           
        /*   categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               System.out.println("data");
               categoria.setDataFinalizacao(data);
           }  */              
        }
        return mensagem;
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
    }
    
    public boolean removerMensagem(Integer menid){
       String sql = "delete from mensagem where menid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,menid);
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
    
    public boolean alteraMensagem(Mensagem mensagem){
       String sql = "update mensagem set mennome = ?, menemail = ?, mendescricao = ? where menid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1,mensagem.getMennome());
        stmt.setString(2,mensagem.getMenemail());
        stmt.setString(3,mensagem.getMendescricao());
   /*     stmt.setBoolean(4,categoria.isFinalizado());
        if(categoria.getDataFinalizacao() != null){
            stmt.setDate(3, new Date(categoria.getDataFinalizacao().getTimeInMillis()));
        }else{
            stmt.setNull(3, java.sql.Types.DATE);
        }*/
        stmt.setInt(4,mensagem.getMenid());
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
}